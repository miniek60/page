<html>
    <head>
        <meta charset="UTF-8">
    </head>
    <body>
        <?php
require "Header.php";
?>
        <div class="wrapper-main">
        <section class="section-default">
    <article>
        <?php
        require 'skrypty/dbp.php';
        $sql = "SELECT * FROM posty WHERE id={$_GET["id"]}";

        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $idKategorii = $row["idKategorii"];
        echo "<h1>".$row["tytul"]."</h1>";
        echo "<p>".$row["tresc"]."</p>";
        echo "<img id='zdj' class='zdjecie' src='{$row['zdjecie']}'>"."<br>";
        echo "<a href='skrypty/deletePost.php?id=".$row["id"]."'>Usuń</a>"."<br>";
        echo "<a href='editPostForm.php?id=".$row["id"]."'>Edytuj</a>"."<br>";
        $sql = "SELECT * FROM kategorie WHERE id='$idKategorii'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        echo "<strong>Kategoria wpisu: ".$row["nazwa"]."</strong>";
        exit();
        
        ?>
       <p><a href="index.php">Strona główna</a></p>;
       </article>
        </section>
    </div>
       <?php
 require "footer.php";
 ?>
    </body>
</html>
