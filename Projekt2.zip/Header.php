<?php
session_start();
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Los Angeles Lakers</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        
        <header>
            <nav class="nav-header-main">
                <a class="header-logo" href="index.php">
                    <img src="img/logo.png" alt="logo">
                </a>
                <ul id="mainMenu">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="history.php">History</a></li>
                    <li><a href="contact.php">Contact</a></li>             
                </ul>
                </nav>
                <div class="header-login">
                    <?php 
                    if (isset($_SESSION['userId'])){
             echo '<a href="#">'.$_SESSION['userUid'].'</a>';
            echo '<form action="skrypty/logout.php" method="post">
                        <button type="submit" name="logout-submit">Logout</button>
                        </form>';
        } else{
            echo '<form action="skrypty/login.php" method="post">
                        <input type="text" name="mailuid" placeholder="Username/E-mail">
                        <input type="password" name="pwd" placeholder="Password">
                        <button type="submit" name="login-submit">Login</button>
                        </form>
                    <button><a href="signup.php">Signup</a></button>';
        }
                    ?>
                    </div>
        </header>
