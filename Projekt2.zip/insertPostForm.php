<?php
require "Header.php";
?>

<main>
    <div class="wrapper-main">
        <section class="section-default">
    <article>
       <h1>Dodaj nowego posta</h1>
        <form action="skrypty/insertPost.php" method="POST">
            <p>Podaj tytuł nowego posta</p>
            <textarea name="tytul">Wpisz tytul</textarea>
            <p>Wpisz tresc posta</p>
            <textarea name="tresc">Wpisz tresc</textarea>
            <p>Podaj kategorie</p>
            <select name="kategoria">
                <option value="1"> Historia </option>
                <option value="2"> Honorowi Zawodnicy </option>
                <option value="3"> Rywalizacje </option>
            </select>
            <p id="zdjecie">Zdjęcie:</p>
            Select image to upload:
            <input type="file" name="zdjecie" id="uploads">
            <br /><br />
            <input type="submit">
        </form>
    </article>
        </section>
    </div>
</main>

<?php
 require "footer.php";
 ?>
