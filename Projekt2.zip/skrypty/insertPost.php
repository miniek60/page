<?php
require 'dbp.php';
$tytul = $_POST["tytul"];
$tresc = $_POST["tresc"];
$kategoria = $_POST["kategoria"];
$zdjecie = $_POST["zdjecie"];

$target_dir = "uploads/.resized";
$target_file = $target_dir . basename($_FILES["zdjecie"]["name"]);
move_uploaded_file($_FILES["zdjecie"]["tmp_name"], $target_file);
$sql = "INSERT into posty(id, idkategorii, tytul, tresc, data, zdjecie) VALUES (NULL, '$kategoria', '$tytul', '$tresc', NULL, '$zdjecie')";
        if($conn->query($sql) === TRUE){
            echo "New record created succesfully";
        } else{
            echo "Error";
        }
        
        
        header("Location: ../insertPostForm.php");
        exit();
?>
