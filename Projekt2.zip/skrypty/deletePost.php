<?php
require 'dbp.php';

$sql = "DELETE FROM posty WHERE id={$_GET["id"]}";
        
        if($conn->query($sql) === TRUE){
            header("Location: ../history.php");
        } else{
            echo "Error".$conn->error;
        }
        exit();
?>

