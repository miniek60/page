<?php
require 'dbp.php';
$output = '';
if(isset($_POST['Search'])){
    $searchq = $_POST['Search'];
    $searchq = preg_replace("#[^0-9a-z]#i","",$searchq);
    
    $sql = "SELECT p.id, p.tytul, p.tresc, k.nazwa, p.data FROM posty p, kategorie k WHERE p.tytul LIKE '%$searchq%'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    echo "<h3>".$row["tytul"]."</h3>";
    echo "<p>".$row["tresc"]."</p>";
    echo "<p>".$row["data"]."</p>";
    echo "<p>".$row["nazwa"]."<p>";
}
exit();
?>
