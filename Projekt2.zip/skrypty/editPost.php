<?php
require 'dbp.php';

$tytul = $_POST["tytul"];
$tresc = $_POST["tresc"];

$sql = "UPDATE posty SET tytul='{$_POST["tytul"]}', tresc='{$_POST["tresc"]}' WHERE id='{$_POST["id"]}'";
        if($conn->query($sql) === TRUE){
            header("Location: ../history.php");
        } else{
            echo "Error";
        }
        exit();
?>
