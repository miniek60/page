<?php
require "Header.php";
?>

<main>
    <div class="wrapper-main">
        <section class="section-default">
    <article>
        <?php
        if (isset($_SESSION['userId'])){
            echo '<p class="login-status">Los Angeles Lakers, mistrzowie tego sezonu NBA i nie tylko !!!</p>';
            echo '<p class="login-status"><img src="img/nba2020.png"  alt="" width="90%" height="700px"></p>';
        } else{
            echo '<p class="login-status">Witam na mojej stronie, gdzie dowiesz się nieco o najlepszej druzynie zwanej Los Angeles Lakers!!!!</p>';
            echo '<p class="login-status">Żeby zobaczyć więcej zaloguj się na moja stronę.</p>';
        }
        ?>
    </article>
        </section>
    </div>
</main>

<?php
 require "footer.php";
 ?>
    

