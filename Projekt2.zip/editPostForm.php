<?php
require "Header.php";
?>

<main>
    <div class="wrapper-main">
        <section class="section-default">
    <article>
        <h1>Edycja posta</h1>
        <form action="skrypty/editPost.php" method="POST">
        <?php      
        require 'skrypty/dbp.php';
        $sql = "SELECT * FROM posty WHERE id =".$_GET["id"]."";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        
        echo "Tytuł posta:</br><input type='text' id='tytul' name='tytul' size='60' value='".$row["tytul"]."'></br></br>";
        echo "Tresc posta:</br><textarea type='text' id='tresc' name='tresc'>",$row["tresc"]."</textarea></br></br>";
        echo "<input type='hidden' name='id' value='".$_GET["id"]."'>";
        ?>
            <input type='submit' value='edytuj'>
        </form>
    </article>
        </section>
    </div>
</main>

<?php
 require "footer.php";
 ?>
