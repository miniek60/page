<?php
require "Header.php";
?>

<main>
    <div class="wrapper-main">
        <section class="section-default">
    <article>
        <?php
        if (isset($_SESSION['userId'])){
            require 'skrypty/dbp.php';
            echo '<p class="login-status"><h1>Historia Los Angeles Lakers!!</h1></p>';
            echo '<p class="login-status"><h2><strong>Kategorie</strong></h2></p>';
            $sql = "SELECT * FROM kategorie";
            $result = $conn->query($sql);
            echo "<p><strong>";
            if ($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
            echo "<a href='history.php?id=".$row["id"]."'>".$row["nazwa"]." ";
            }
            } else{
            echo "Brak kategorii";
            }
            echo " <a href='history.php'>Wszystkie</a></p></strong><br />";
            echo "<form action='skrypty/Search.php' method='post'>
            <textarea name='Search'>Wyszukaj postu</textarea>
            <input type='submit' value='Search'>
             </form>";
            echo "<table class='center'><tr><th>Tytuł</th><th>Kategoria</th><th>Data Dodania</th><th>Zdjecie</th><th>Usuwanie</th><th>Edytowanie</th></tr>";
            $sql = "SELECT p.id, p.tytul, k.nazwa, p.data , p.zdjecie FROM posty p, kategorie k WHERE p.idKategorii = k.id";
            if(isset($_GET["id"])) {
            $sql = "SELECT p.id, p.tytul, k.nazwa, p.data, p.zdjecie FROM posty p, kategorie k WHERE p.idKategorii = k.id AND p.idKategorii = {$_GET["id"]}";
            }
            $result = $conn->query($sql);
            if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
            echo "<tr><td><a href='post.php?id=".$row["id"]."'>".$row["tytul"]."</a></td><td>".$row["nazwa"]."</td><td>".$row["data"]."</td><td>".$row["zdjecie"]."</td><td><a href='skrypty/deletePost.php?id=".$row["id"]."'>Usuń</a></td><td><a href='editPostForm.php?id=".$row["id"]."'>Edytuj</a></td></tr>";
            }
            } else{
            echo "Brak kategorii";
            }
            echo "</table>";
            echo "<br /><p><a href='insertPostForm.php'><strong>Dodaj Nowy Post</strong></a></p>";
            exit(); 
                 
        } else{
            echo '<p class="login-status">Tutaj dowiesz się nieco o historii Los Angeles Lakers!</p>';
            echo '<p class="login-status">Żeby zobaczyć więcej zaloguj się na moja stronę.</p>';
            }

        ?>
    </article>
        </section>
    </div>
</main>

<?php
 require "footer.php";
 ?>
