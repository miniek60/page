<?php
require "Header.php";
?>

<main>
    <div class="wrapper-main">
        <section class="section-default">
    <article>
        <?php
        if (isset($_SESSION['userId'])){
            echo '<p class="login-status">Kontakt ze mną:</p>';
            echo '<p class="login-status">Numer telefonu: 999 888 777</p>';
            echo '<p class="login-status">Adres e-mail: LaLakers@gmail.com</p>';
        } else{
            echo '<p class="login-status">Tutaj masz wszystkie dane potrzebne do skontaktowania się ze mną!!</p>';
            echo '<p class="login-status">Żeby zobaczyć więcej zaloguj się na moja stronę.</p>';
        }
        ?>
    </article>
        </section>
    </div>
</main>

<?php
 require "footer.php";
 ?>
